import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAuth } from '../../context/AuthContext';
import { adjustPartStock } from '../../lib/inventory';
import { confirmAction } from '../../components/ConfirmModal';

const EMPTY_FORM = {
  name: '',
  category: '',
  price: '',
  stock_quantity: '',
  reorder_threshold: '5',
  compatible_models: '',
  image_url: '',
  ai_reference_url: '',
  prompt_description: '',
  install_area: '',
  color: '',
  finish: '',
  material: '',
  is_previewable: false,
};

const PRODUCT_IMAGE_BUCKET = 'product-images';
const AI_REFERENCE_BUCKET = 'product-ai-references';
const MAX_IMAGE_SIZE_MB = 5;

const STOCK_FILTERS = [
  { key: 'all', label: 'All Stock Levels' },
  { key: 'low', label: 'Low Stock' },
  { key: 'out', label: 'Out of Stock' },
];

const STATUS_FILTERS = [
  { key: 'active', label: 'Active' },
  { key: 'inactive', label: 'Inactive' },
  { key: 'all', label: 'All' },
];

const PAGE_SIZE_OPTIONS = [6, 9, 12, 24, 48];

const INSTALL_AREA_OPTIONS = [
  'Front wheel/rim area only',
  'Rear wheel/rim area only',
  'Front and rear wheel/rim area only',
  'Visible exhaust/muffler system',
  'Seat area',
  'Handlebar/control area',
  'Headlight/front lighting area',
  'Tail light/rear lighting area',
  'Side mirror mounting area',
  'Brake caliper/rotor area',
  'Suspension/shock absorber area',
  'Engine/engine cover area',
  'Radiator/cooling area',
  'Body panel/fairing area',
  'License plate holder/rear fender area',
  'Top box/rear carrier mounting area',
];

function getCategoryRecord(category, categoryRecords = []) {
  const cleanCategory = sanitizeCategory(category).toLowerCase().trim();

  if (!cleanCategory) return null;

  return (
    categoryRecords.find(
      (item) => sanitizeCategory(item?.name).toLowerCase().trim() === cleanCategory
    ) || null
  );
}

function getCategoryPreviewInfo(category, categoryRecords = []) {
  const cleanCategory = sanitizeCategory(category).trim();

  if (!cleanCategory) {
    return {
      isPreviewable: false,
      label: 'Select category first',
      helper: 'Choose a category before uploading photos.',
    };
  }

  const categoryRecord = getCategoryRecord(cleanCategory, categoryRecords);

  if (!categoryRecord) {
    return {
      isPreviewable: false,
      label: 'Shop Only',
      helper:
        'This category is not saved in Manage Categories yet. Add it there and enable AI Preview if it should be previewable.',
    };
  }

  if (categoryRecord.is_previewable === true) {
    return {
      isPreviewable: true,
      label: 'Previewable',
      helper:
        'This category is marked as AI-previewable in Manage Categories, so AI Preview fields are enabled.',
    };
  }

  return {
    isPreviewable: false,
    label: 'Shop Only',
    helper:
      'This category is marked as Shop Only in Manage Categories, so it will not appear in AI Preview.',
  };
}

function formatPeso(value, decimals = 2) {
  const amount = Number(value) || 0;

  return `₱${amount.toLocaleString('en-PH', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

function formatDateTime(value) {
  if (!value) return '—';

  return new Date(value).toLocaleString('en-PH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function parseCompatibleModels(value) {
  return String(value || '')
    .split(',')
    .map((item) => sanitizeCompatibleModel(item))
    .filter(Boolean)
    .slice(0, 20);
}

function sanitizeProductName(value) {
  return String(value || '')
    .replace(/[^a-zA-Z0-9ñÑ .,'’()\-/+&]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 100);
}

function sanitizeCategory(value) {
  return String(value || '')
    .replace(/[^a-zA-Z0-9ñÑ .,'’()\-/+&]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 60);
}

function sanitizeCompatibleModel(value) {
  return String(value || '')
    .replace(/[^a-zA-Z0-9ñÑ .,'’()\-/+&]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 80);
}

function sanitizeCompatibleModels(value) {
  return String(value || '')
    .split(',')
    .map((item) => sanitizeCompatibleModel(item))
    .filter(Boolean)
    .join(', ')
    .slice(0, 500);
}

function sanitizeMoneyInput(value) {
  const clean = String(value || '')
    .replace(/[^0-9.]/g, '')
    .replace(/(\..*)\./g, '$1');

  const [whole = '', decimal = ''] = clean.split('.');

  return decimal !== undefined && clean.includes('.')
    ? `${whole.slice(0, 8)}.${decimal.slice(0, 2)}`
    : whole.slice(0, 8);
}

function sanitizeIntegerInput(value, maxDigits = 6) {
  return String(value || '').replace(/\D/g, '').slice(0, maxDigits);
}

function sanitizeAiText(value, maxLength = 240) {
  return String(value || '')
    .replace(/[^a-zA-Z0-9ñÑ .,'’()\-/+&#:%]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, maxLength);
}

function sanitizeBasicText(value, maxLength = 80) {
  return String(value || '')
    .replace(/[^a-zA-Z0-9ñÑ .,'’()\-/+&#]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, maxLength);
}

function formatMotorcycleModel(model) {
  const label = [model?.make, model?.model].filter(Boolean).join(' ');
  return sanitizeCompatibleModel(label);
}

function getStockState(part) {
  const stock = Number(part.stock_quantity) || 0;
  const threshold = Number(part.reorder_threshold ?? 5);

  if (stock <= 0) return 'out';
  if (stock <= threshold) return 'low';
  return 'ok';
}

function getStockLabel(state) {
  if (state === 'out') return 'Out of Stock';
  if (state === 'low') return 'Low Stock';
  return 'In Stock';
}

const STOCK_STYLES = {
  ok: 'bg-green-50 text-green-700 ring-green-200 dark:bg-green-500/10 dark:text-green-300 dark:ring-green-500/25',
  low: 'bg-yellow-50 text-yellow-700 ring-yellow-200 dark:bg-yellow-500/10 dark:text-yellow-300 dark:ring-yellow-500/25',
  out: 'bg-red-50 text-red-700 ring-red-200 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25',
};

const STOCK_BAR = {
  ok: 'bg-green-500',
  low: 'bg-yellow-400',
  out: 'bg-red-500',
};

function StockBadge({ state }) {
  return (
    <span className={`inline-flex rounded-full px-3 py-1 text-xs font-black ring-1 ${STOCK_STYLES[state]}`}>
      {getStockLabel(state)}
    </span>
  );
}

function StatCard({ label, value, icon, tone = 'default' }) {
  const tones = {
    default: 'text-gray-950 dark:text-white',
    primary: 'text-primary-600 dark:text-primary-400',
    accent: 'text-accent-600 dark:text-accent-400',
    green: 'text-green-600 dark:text-green-300',
    yellow: 'text-yellow-600 dark:text-yellow-300',
    red: 'text-red-600 dark:text-red-300',
  };

  return (
    <div className="rounded-3xl border border-gray-200 bg-white p-5 shadow-sm dark:border-dark-700 dark:bg-dark-800">
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-[11px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
          {label}
        </p>
        <span className="text-2xl">{icon}</span>
      </div>
      <p className={`text-2xl font-black ${tones[tone] || tones.default}`}>
        {value}
      </p>
    </div>
  );
}

function TextInput({ label, helper, ...props }) {
  return (
    <div>
      <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
        {label}
      </label>
      <input
        {...props}
        className={`w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-primary-500 focus:bg-white focus:ring-4 focus:ring-primary-500/10 disabled:cursor-not-allowed disabled:opacity-50 dark:border-dark-700 dark:bg-dark-900 dark:text-white dark:placeholder:text-gray-500 ${props.className || ''}`}
      />
      {helper && <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">{helper}</p>}
    </div>
  );
}

function PartSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {[1, 2, 3, 4, 5, 6].map((item) => (
        <div
          key={item}
          className="h-80 animate-pulse rounded-3xl bg-white ring-1 ring-gray-200 dark:bg-dark-800 dark:ring-dark-700"
        />
      ))}
    </div>
  );
}

export default function AdminParts() {
  const { user } = useAuth();

  const [parts, setParts] = useState([]);
  const [motorcycleModels, setMotorcycleModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState('');
  const [errorPopup, setErrorPopup] = useState(null);

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [stockFilter, setStockFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('active');
  const [sortBy, setSortBy] = useState('name');

  const [panelOpen, setPanelOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadingAiReference, setUploadingAiReference] = useState(false);

  const [toast, setToast] = useState('');
  const [togglingId, setTogglingId] = useState(null);
  const [stockEdits, setStockEdits] = useState({});
  const [updatingStockId, setUpdatingStockId] = useState(null);

  const [catPanelOpen, setCatPanelOpen] = useState(false);
  const [categoryRecords, setCategoryRecords] = useState([]);
  const [newCatName, setNewCatName] = useState('');
  const [newCatPreviewable, setNewCatPreviewable] = useState(false);
  const [renamingCat, setRenamingCat] = useState(null);
  const [catSaving, setCatSaving] = useState(false);
  const [showCategoryInput, setShowCategoryInput] = useState(false);

  const [lastUpdated, setLastUpdated] = useState(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(9);

  const categoryPreviewInfo = useMemo(
    () => getCategoryPreviewInfo(form.category, categoryRecords),
    [form.category, categoryRecords]
  );

  const hasSelectedCategory = Boolean(sanitizeCategory(form.category).trim());

  useEffect(() => {
    fetchParts();
    fetchMotorcycleModels();
    fetchPartCategories();

    /*
      Realtime refresh for inventory management.
      Enable Realtime in Supabase for parts.
    */
    const partsChannel = supabase
      .channel('admin-parts-inventory')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'parts',
        },
        () => fetchParts(false)
      )
      .subscribe();

    const motorcycleModelsChannel = supabase
      .channel('admin-parts-motorcycle-models')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'motorcycle_models',
        },
        () => fetchMotorcycleModels()
      )
      .subscribe();

    const partCategoriesChannel = supabase
      .channel('admin-parts-categories')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'part_categories',
        },
        () => fetchPartCategories(false)
      )
      .subscribe();

    const handleFocus = () => {
      fetchParts(false);
      fetchMotorcycleModels();
      fetchPartCategories(false);
    };

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        fetchParts(false);
        fetchMotorcycleModels();
        fetchPartCategories(false);
      }
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      supabase.removeChannel(partsChannel);
      supabase.removeChannel(motorcycleModelsChannel);
      supabase.removeChannel(partCategoriesChannel);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  useEffect(() => {
    if (!toast) return;

    const timeout = setTimeout(() => setToast(''), 3000);
    return () => clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, categoryFilter, stockFilter, statusFilter, sortBy, pageSize]);

  function showErrorPopup(message) {
    const cleanMessage =
      typeof message === 'string' && message.trim()
        ? message
        : 'Something went wrong. Please try again.';

    setFetchError(cleanMessage);
    setErrorPopup(cleanMessage);
  }

  function showFormError(message) {
    const cleanMessage =
      typeof message === 'string' && message.trim()
        ? message
        : 'Please check the form and try again.';

    setFormError(cleanMessage);
    setErrorPopup(cleanMessage);
  }

  function clearErrorPopup() {
    setErrorPopup(null);
    setFetchError('');
  }

  async function fetchParts(showLoader = true) {
    if (showLoader) setLoading(true);

    setFetchError('');

    const { data, error } = await supabase
      .from('parts')
      .select('*')
      .order('name', { ascending: true });

    if (error) {
      const message = error.message || 'Failed to load products.';
      setFetchError(message);
      if (showLoader) setErrorPopup(message);
      setParts([]);
      setLoading(false);
      return;
    }

    setParts(data || []);
    setLastUpdated(new Date());
    setLoading(false);
  }

  async function fetchMotorcycleModels() {
    const { data, error } = await supabase
      .from('motorcycle_models')
      .select('id, make, model')
      .order('make', { ascending: true })
      .order('model', { ascending: true });

    if (error) {
      console.log('Fetch motorcycle models error:', error.message);
      setMotorcycleModels([]);
      return;
    }

    const uniqueModels = [];
    const seen = new Set();

    (data || []).forEach((model) => {
      const label = formatMotorcycleModel(model);

      if (!label || seen.has(label.toLowerCase())) return;

      seen.add(label.toLowerCase());
      uniqueModels.push({
        id: model.id,
        label,
      });
    });

    setMotorcycleModels(uniqueModels);
  }

  async function fetchPartCategories(showPopup = false) {
    const { data, error } = await supabase
      .from('part_categories')
      .select('id, name, is_previewable, is_active, created_at, updated_at')
      .order('name', { ascending: true });

    if (error) {
      console.log('Fetch product categories error:', error.message);
      setCategoryRecords([]);

      if (showPopup) {
        showErrorPopup(
          'Failed to load product categories. Please run the part_categories SQL setup first.'
        );
      }

      return;
    }

    setCategoryRecords(data || []);
  }

  async function insertAuditLog(action, entityId, details = {}) {
    if (!user?.id) return;

    await supabase.from('audit_logs').insert({
      action,
      entity: 'parts',
      entity_id: entityId || null,
      performed_by: user.id,
      details,
    });
  }

  function sanitizeFileName(name) {
    return String(name || 'image')
      .toLowerCase()
      .replace(/[^a-z0-9.]+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }

  async function uploadProductImageFile({ file, bucket, folder = 'uploads' }) {
    if (!file) return '';

    if (!file.type?.startsWith('image/')) {
      throw new Error('Please upload an image file only.');
    }

    const maxBytes = MAX_IMAGE_SIZE_MB * 1024 * 1024;

    if (file.size > maxBytes) {
      throw new Error(`Image is too large. Maximum size is ${MAX_IMAGE_SIZE_MB}MB.`);
    }

    const cleanName = sanitizeFileName(file.name);
    const fileExt = cleanName.includes('.') ? cleanName.split('.').pop() : 'jpg';
    const filePath = `${folder}/${Date.now()}-${Math.random()
      .toString(36)
      .slice(2)}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type,
      });

    if (uploadError) {
      throw uploadError;
    }

    const { data } = supabase.storage.from(bucket).getPublicUrl(filePath);

    if (!data?.publicUrl) {
      throw new Error('Image uploaded, but public URL could not be generated.');
    }

    return data.publicUrl;
  }

  async function handleProductImageUpload(event) {
    const file = event.target.files?.[0];

    if (!file) return;

    if (!hasSelectedCategory) {
      event.target.value = '';
      showFormError('Please select the product category first before uploading a photo.');
      return;
    }

    setUploadingImage(true);
    setFormError('');

    try {
      const publicUrl = await uploadProductImageFile({
        file,
        bucket: PRODUCT_IMAGE_BUCKET,
        folder: 'products',
      });

      setForm((current) => ({
        ...current,
        image_url: publicUrl,
      }));

      setToast('✓ Product image uploaded');
    } catch (err) {
      showFormError(err.message || 'Failed to upload product image.');
    } finally {
      setUploadingImage(false);
      event.target.value = '';
    }
  }

  async function handleAiReferenceUpload(event) {
    const file = event.target.files?.[0];

    if (!file) return;

    const previewInfo = getCategoryPreviewInfo(form.category, categoryRecords);

    if (!previewInfo.isPreviewable) {
      event.target.value = '';
      showFormError('This category is Shop Only and cannot use AI Preview.');
      return;
    }

    setUploadingAiReference(true);
    setFormError('');

    try {
      const publicUrl = await uploadProductImageFile({
        file,
        bucket: AI_REFERENCE_BUCKET,
        folder: 'ai-references',
      });

      setForm((current) => ({
        ...current,
        ai_reference_url: publicUrl,
      }));

      setToast('✓ AI reference image uploaded');
    } catch (err) {
      showFormError(err.message || 'Failed to upload AI reference image.');
    } finally {
      setUploadingAiReference(false);
      event.target.value = '';
    }
  }

  function handleChange(event) {
    const { name, value, type, checked } = event.target;

    const sanitizers = {
      name: sanitizeProductName,
      category: sanitizeCategory,
      price: sanitizeMoneyInput,
      stock_quantity: (input) => sanitizeIntegerInput(input, 6),
      reorder_threshold: (input) => sanitizeIntegerInput(input, 4),
      compatible_models: sanitizeCompatibleModels,
      prompt_description: (input) => sanitizeAiText(input, 240),
      install_area: (input) => sanitizeAiText(input, 220),
      color: (input) => sanitizeBasicText(input, 40),
      finish: (input) => sanitizeBasicText(input, 50),
      material: (input) => sanitizeBasicText(input, 50),
    };

    setForm((current) => ({
      ...current,
      [name]: type === 'checkbox' ? checked : sanitizers[name] ? sanitizers[name](value) : value,
    }));
  }

  function applyCategoryToForm(value) {
    const cleanCategory = sanitizeCategory(value);
    const previewInfo = getCategoryPreviewInfo(cleanCategory, categoryRecords);

    setForm((current) => {
      const next = {
        ...current,
        category: cleanCategory,
        is_previewable: previewInfo.isPreviewable,
      };

      if (!previewInfo.isPreviewable) {
        next.ai_reference_url = '';
        next.prompt_description = '';
        next.install_area = '';
        next.color = '';
        next.finish = '';
        next.material = '';
      }

      return next;
    });
  }

  function handleCategorySelect(event) {
    const value = event.target.value;

    if (value === '__other__') {
      setShowCategoryInput(true);
      applyCategoryToForm('');
      return;
    }

    applyCategoryToForm(value);
  }

  function handleCategoryInputChange(event) {
    applyCategoryToForm(event.target.value);
  }

  function openAddPanel() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormError('');
    setShowCategoryInput(false);
    setPanelOpen(true);
  }

  function openEditPanel(part) {
    const previewInfo = getCategoryPreviewInfo(part.category || '', categoryRecords);

    setEditingId(part.id);
    setForm({
      name: part.name || '',
      category: part.category || '',
      price: String(part.price ?? ''),
      stock_quantity: String(part.stock_quantity ?? ''),
      reorder_threshold: String(part.reorder_threshold ?? '5'),
      compatible_models: (part.compatible_models || []).join(', '),
      image_url: part.image_url || '',
      ai_reference_url: previewInfo.isPreviewable ? part.ai_reference_url || '' : '',
      prompt_description: previewInfo.isPreviewable ? part.prompt_description || '' : '',
      install_area: previewInfo.isPreviewable ? part.install_area || '' : '',
      color: previewInfo.isPreviewable ? part.color || '' : '',
      finish: previewInfo.isPreviewable ? part.finish || '' : '',
      material: previewInfo.isPreviewable ? part.material || '' : '',
      is_previewable: previewInfo.isPreviewable,
    });
    setFormError('');
    setShowCategoryInput(false);
    setPanelOpen(true);
  }

  function closePanel() {
    setPanelOpen(false);
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormError('');
    setShowCategoryInput(false);
  }

  function validateForm() {
    const name = sanitizeProductName(form.name).trim();
    const category = sanitizeCategory(form.category).trim();
    const price = parseFloat(form.price);
    const stock = parseInt(form.stock_quantity, 10);
    const threshold = parseInt(form.reorder_threshold || '5', 10);
    const previewInfo = getCategoryPreviewInfo(category, categoryRecords);

    if (!category) return 'Category is required before saving the product.';
    if (category.length < 2) return 'Category must be at least 2 characters.';

    if (!name) return 'Product name is required.';
    if (name.length < 2) return 'Product name must be at least 2 characters.';

    if (Number.isNaN(price) || price < 0) return 'Please enter a valid price.';
    if (price > 99999999) return 'Price is too high. Please check the amount.';

    if (Number.isNaN(stock) || stock < 0) return 'Please enter a valid stock quantity.';
    if (stock > 999999) return 'Stock quantity is too high.';

    if (Number.isNaN(threshold) || threshold < 0) {
      return 'Please enter a valid reorder threshold.';
    }

    if (threshold > 9999) return 'Reorder threshold is too high.';

    if (previewInfo.isPreviewable && !INSTALL_AREA_OPTIONS.includes(form.install_area)) {
      return 'Please select a predefined install area for AI Preview.';
    }

    return '';
  }

  async function handleSubmit(event) {
    event.preventDefault();

    setFormError('');

    const validationError = validateForm();

    if (validationError) {
      showFormError(validationError);
      return;
    }

    const stockQuantity = parseInt(form.stock_quantity, 10);
    const cleanProductName = sanitizeProductName(form.name).trim();

    const confirmed = await confirmAction(
      editingId
        ? `Save changes to "${cleanProductName}"?`
        : `Add "${cleanProductName}" as a new product?`
    );

    if (!confirmed) return;

    setSaving(true);

    const previewInfo = getCategoryPreviewInfo(form.category, categoryRecords);

    const payload = {
      name: cleanProductName,
      category: sanitizeCategory(form.category).trim(),
      price: parseFloat(sanitizeMoneyInput(form.price)),
      reorder_threshold: parseInt(sanitizeIntegerInput(form.reorder_threshold || '5', 4), 10),
      compatible_models: parseCompatibleModels(form.compatible_models),
      image_url: form.image_url || null,
      ai_reference_url: previewInfo.isPreviewable ? form.ai_reference_url || null : null,
      prompt_description: previewInfo.isPreviewable
        ? sanitizeAiText(form.prompt_description, 240).trim() || null
        : null,
      install_area:
        previewInfo.isPreviewable && INSTALL_AREA_OPTIONS.includes(form.install_area)
          ? form.install_area
          : null,
      color: previewInfo.isPreviewable
        ? sanitizeBasicText(form.color, 40).trim() || null
        : null,
      finish: previewInfo.isPreviewable
        ? sanitizeBasicText(form.finish, 50).trim() || null
        : null,
      material: previewInfo.isPreviewable
        ? sanitizeBasicText(form.material, 50).trim() || null
        : null,
      is_previewable: previewInfo.isPreviewable,
    };

    try {
      if (editingId) {
        const currentPart = parts.find((part) => part.id === editingId);
        const currentStock = Number(currentPart?.stock_quantity) || 0;

        const { error } = await supabase
          .from('parts')
          .update(payload)
          .eq('id', editingId);

        if (error) throw error;

        if (stockQuantity !== currentStock) {
          const difference = Math.abs(stockQuantity - currentStock);
          const movementType = stockQuantity > currentStock ? 'stock_in' : 'stock_out';

          await adjustPartStock({
            partId: editingId,
            movementType,
            quantity: difference,
            reason:
              stockQuantity > currentStock
                ? 'Stock increased from edit product form'
                : 'Stock decreased from edit product form',
          });
        }

        await insertAuditLog('UPDATE_PART', editingId, {
          ...payload,
          previous_stock_quantity: currentStock,
          new_stock_quantity: stockQuantity,
        });

        setToast(`✓ ${payload.name} updated`);
      } else {
        const { data, error } = await supabase
          .from('parts')
          .insert({
            ...payload,
            stock_quantity: 0,
            is_active: true,
          })
          .select('id')
          .single();

        if (error) throw error;

        if (stockQuantity > 0) {
          await adjustPartStock({
            partId: data.id,
            movementType: 'stock_in',
            quantity: stockQuantity,
            reason: 'Initial stock when product was created',
          });
        }

        await insertAuditLog('CREATE_PART', data.id, {
          name: payload.name,
          price: payload.price,
          stock_quantity: stockQuantity,
        });

        setToast(`✓ ${payload.name} added to inventory`);
      }

      closePanel();
      await fetchParts(false);
    } catch (err) {
      showFormError(err.message || 'Failed to save product.');
    } finally {
      setSaving(false);
    }
  }

  async function setPartActive(part, active) {
    setTogglingId(part.id);

    try {
      const { error } = await supabase
        .from('parts')
        .update({ is_active: active })
        .eq('id', part.id);

      if (error) throw error;

      await insertAuditLog(active ? 'REACTIVATE_PART' : 'DEACTIVATE_PART', part.id, {
        name: part.name,
      });

      setToast(active ? `✓ ${part.name} reactivated` : `${part.name} deactivated`);
      await fetchParts(false);
    } catch (err) {
      const message = err.message || 'Failed to update product.';
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setTogglingId(null);
    }
  }

  async function updateStock(id, qty, reason = 'Manual stock adjustment') {
    if (Number.isNaN(qty) || qty < 0) return;

    const currentPart = parts.find((part) => part.id === id);
    if (!currentPart) return;

    const currentStock = Number(currentPart.stock_quantity) || 0;
    if (qty === currentStock) return;

    const quantity = Math.abs(qty - currentStock);
    const movementType = qty > currentStock ? 'stock_in' : 'stock_out';

    setUpdatingStockId(id);
    const previous = parts;

    setParts((current) =>
      current.map((part) => (part.id === id ? { ...part, stock_quantity: qty } : part))
    );

    try {
      await adjustPartStock({
        partId: id,
        movementType,
        quantity,
        reason,
      });

      setToast(`✓ Stock updated: ${currentStock} → ${qty}`);
      await fetchParts(false);
    } catch (err) {
      const message = err.message || 'Failed to update stock.';
      setParts(previous);
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setUpdatingStockId(null);
    }
  }

  async function adjustStock(part, delta) {
    const currentStock = Number(part.stock_quantity) || 0;
    const next = Math.max(0, currentStock + delta);

    if (next === currentStock) return;

    const actionText = delta > 0 ? 'increase' : 'decrease';
    const confirmed = await confirmAction(
      `Are you sure you want to ${actionText} stock for "${part.name}" from ${currentStock} to ${next}?`
    );

    if (!confirmed) return;

    updateStock(
      part.id,
      next,
      delta > 0
        ? 'Stock increased with quick add button'
        : 'Stock decreased with quick subtract button'
    );
  }

  async function commitStockInput(part) {
    const raw = stockEdits[part.id];

    if (raw === undefined) return;

    const qty = parseInt(raw, 10);
    const currentStock = Number(part.stock_quantity) || 0;

    if (!Number.isNaN(qty) && qty >= 0 && qty !== currentStock) {
      const confirmed = await confirmAction(
        `Update stock for "${part.name}" from ${currentStock} to ${qty}?`
      );

      if (confirmed) {
        updateStock(part.id, qty, 'Stock adjusted from manual stock input');
      }
    }

    setStockEdits((previous) => {
      const next = { ...previous };
      delete next[part.id];
      return next;
    });
  }

  const derivedCategories = useMemo(
    () => [...new Set(parts.map((part) => sanitizeCategory(part.category).trim()).filter(Boolean))].sort(),
    [parts]
  );

  const activeCategoryRecords = useMemo(
    () => categoryRecords.filter((category) => category.is_active !== false),
    [categoryRecords]
  );

  const allCategories = useMemo(
    () =>
      [
        ...new Set([
          ...activeCategoryRecords.map((category) => sanitizeCategory(category.name).trim()).filter(Boolean),
          ...derivedCategories,
        ]),
      ].sort(),
    [activeCategoryRecords, derivedCategories]
  );

  const categories = useMemo(() => ['all', ...allCategories], [allCategories]);

  const selectedCompatibleModels = useMemo(
    () => parseCompatibleModels(form.compatible_models),
    [form.compatible_models]
  );

  function toggleCompatibleModel(modelLabel) {
    const cleanModel = sanitizeCompatibleModel(modelLabel).trim();

    if (!cleanModel) return;

    setForm((current) => {
      const currentModels = parseCompatibleModels(current.compatible_models);
      const exists = currentModels.some(
        (model) => model.toLowerCase() === cleanModel.toLowerCase()
      );

      const nextModels = exists
        ? currentModels.filter((model) => model.toLowerCase() !== cleanModel.toLowerCase())
        : [...currentModels, cleanModel];

      return {
        ...current,
        compatible_models: nextModels.join(', '),
      };
    });
  }

  function clearCompatibleModels() {
    setForm((current) => ({
      ...current,
      compatible_models: '',
    }));
  }

  async function addCustomCategory() {
    const name = sanitizeCategory(newCatName).trim();

    if (!name) return;

    if (allCategories.map((category) => category.toLowerCase()).includes(name.toLowerCase())) {
      const message = `Category "${name}" already exists`;
      setToast(message);
      setErrorPopup(message);
      return;
    }

    setCatSaving(true);

    try {
      const { error } = await supabase.from('part_categories').insert({
        name,
        is_previewable: newCatPreviewable,
        is_active: true,
      });

      if (error) throw error;

      await insertAuditLog('CREATE_CATEGORY', null, {
        category: name,
        is_previewable: newCatPreviewable,
      });

      setNewCatName('');
      setNewCatPreviewable(false);
      setToast(
        `✓ Category "${name}" added as ${newCatPreviewable ? 'Previewable' : 'Shop Only'}`
      );
      await fetchPartCategories(false);
    } catch (err) {
      const message = err.message || 'Failed to add category.';
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setCatSaving(false);
    }
  }

  async function renameCategory(oldName, newName) {
    const trimmed = sanitizeCategory(newName).trim();
    const categoryRecord = getCategoryRecord(oldName, categoryRecords);

    if (!trimmed || trimmed === oldName) {
      setRenamingCat(null);
      return;
    }

    setCatSaving(true);

    try {
      if (categoryRecord?.id) {
        const { error } = await supabase
          .from('part_categories')
          .update({ name: trimmed })
          .eq('id', categoryRecord.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('parts')
          .update({ category: trimmed })
          .eq('category', oldName);

        if (error) throw error;
      }

      await insertAuditLog('RENAME_CATEGORY', null, {
        old_category: oldName,
        new_category: trimmed,
      });

      if (categoryFilter === oldName) setCategoryFilter(trimmed);
      if (form.category === oldName) applyCategoryToForm(trimmed);

      setToast(`✓ Renamed "${oldName}" → "${trimmed}"`);
      await fetchPartCategories(false);
      await fetchParts(false);
    } catch (err) {
      const message = err.message || 'Failed to rename category.';
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setRenamingCat(null);
      setCatSaving(false);
    }
  }

  async function toggleCategoryPreviewable(categoryName, nextValue) {
    const categoryRecord = getCategoryRecord(categoryName, categoryRecords);

    if (!categoryRecord?.id) {
      showErrorPopup('Category record not found. Please refresh and try again.');
      return;
    }

    const confirmed = await confirmAction(
      nextValue
        ? `Enable AI Preview for "${categoryName}"? Products in this category can use AI preview fields.`
        : `Disable AI Preview for "${categoryName}"? AI reference and preview fields will be cleared for products in this category.`
    );

    if (!confirmed) return;

    setCatSaving(true);

    try {
      const { error } = await supabase
        .from('part_categories')
        .update({ is_previewable: nextValue })
        .eq('id', categoryRecord.id);

      if (error) throw error;

      await insertAuditLog('UPDATE_CATEGORY_PREVIEW_SETTING', null, {
        category: categoryName,
        is_previewable: nextValue,
      });

      if (form.category === categoryName && !nextValue) {
        applyCategoryToForm(categoryName);
      }

      setToast(`✓ ${categoryName} set to ${nextValue ? 'Previewable' : 'Shop Only'}`);
      await fetchPartCategories(false);
      await fetchParts(false);
    } catch (err) {
      const message = err.message || 'Failed to update category preview setting.';
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setCatSaving(false);
    }
  }

  async function deleteCategory(name) {
    if (!await confirmAction(`Remove category "${name}" from all products?`)) return;

    const categoryRecord = getCategoryRecord(name, categoryRecords);

    setCatSaving(true);

    try {
      const { error: clearError } = await supabase
        .from('parts')
        .update({ category: null })
        .eq('category', name);

      if (clearError) throw clearError;

      if (categoryRecord?.id) {
        const { error: deleteError } = await supabase
          .from('part_categories')
          .delete()
          .eq('id', categoryRecord.id);

        if (deleteError) throw deleteError;
      }

      await insertAuditLog('DELETE_CATEGORY', null, {
        category: name,
      });

      if (categoryFilter === name) setCategoryFilter('all');
      if (form.category === name) applyCategoryToForm('');

      setToast(`Removed category "${name}"`);
      await fetchPartCategories(false);
      await fetchParts(false);
    } catch (err) {
      const message = err.message || 'Failed to remove category.';
      setToast(`❌ ${message}`);
      showErrorPopup(message);
    } finally {
      setCatSaving(false);
    }
  }

  const stats = useMemo(() => {
    const activeParts = parts.filter((part) => part.is_active !== false);
    const totalValue = activeParts.reduce(
      (sum, part) => sum + (Number(part.price) || 0) * (Number(part.stock_quantity) || 0),
      0
    );
    const lowStock = activeParts.filter((part) => getStockState(part) === 'low').length;
    const outOfStock = activeParts.filter((part) => getStockState(part) === 'out').length;

    return {
      totalValue,
      lowStock,
      outOfStock,
      total: activeParts.length,
      inactive: parts.filter((part) => part.is_active === false).length,
    };
  }, [parts]);

  const filteredParts = useMemo(() => {
    const searchTerm = search.trim().toLowerCase();

    let result = parts.filter((part) => {
      const stockState = getStockState(part);
      const compatibleModels = (part.compatible_models || []).join(' ').toLowerCase();
      const isActive = part.is_active !== false;

      const aiSearchText = [
        part.prompt_description,
        part.install_area,
        part.color,
        part.finish,
        part.material,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      const matchesSearch =
        !searchTerm ||
        String(part.name || '').toLowerCase().includes(searchTerm) ||
        String(part.category || '').toLowerCase().includes(searchTerm) ||
        compatibleModels.includes(searchTerm) ||
        aiSearchText.includes(searchTerm);

      const matchesCategory =
        categoryFilter === 'all' || part.category === categoryFilter;

      const matchesStock =
        stockFilter === 'all' || stockFilter === stockState;

      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'active' && isActive) ||
        (statusFilter === 'inactive' && !isActive);

      return matchesSearch && matchesCategory && matchesStock && matchesStatus;
    });

    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'price_asc':
          return (Number(a.price) || 0) - (Number(b.price) || 0);
        case 'price_desc':
          return (Number(b.price) || 0) - (Number(a.price) || 0);
        case 'stock_asc':
          return (Number(a.stock_quantity) || 0) - (Number(b.stock_quantity) || 0);
        case 'stock_desc':
          return (Number(b.stock_quantity) || 0) - (Number(a.stock_quantity) || 0);
        default:
          return String(a.name || '').localeCompare(String(b.name || ''));
      }
    });

    return result;
  }, [parts, search, categoryFilter, stockFilter, statusFilter, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filteredParts.length / pageSize));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (safeCurrentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedParts = filteredParts.slice(startIndex, endIndex);

  function clearFilters() {
    setSearch('');
    setCategoryFilter('all');
    setStockFilter('all');
    setStatusFilter('active');
    setSortBy('name');
  }

  return (
    <div className="min-h-[calc(100vh-65px)] bg-gray-50 px-4 py-8 text-gray-900 dark:bg-dark-900 dark:text-white sm:px-6 lg:py-10">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-2 text-xs font-black uppercase tracking-[0.25em] text-primary-600 dark:text-primary-400">
              MotoFix Admin
            </p>
            <h1 className="text-3xl font-black tracking-tight text-gray-950 dark:text-white">
              Products
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-600 dark:text-gray-400">
              Add products, upload images, update stock, and manage categories.
            </p>
            {lastUpdated && (
              <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                Last updated: {formatDateTime(lastUpdated)}
              </p>
            )}
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => fetchParts(false)}
              className="rounded-2xl border border-gray-200 bg-white px-5 py-3 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 dark:border-dark-700 dark:bg-dark-800 dark:text-gray-300 dark:hover:border-primary-500 dark:hover:text-primary-400"
            >
              Refresh
            </button>

            <button
              type="button"
              onClick={() => setCatPanelOpen(true)}
              className="rounded-2xl border border-gray-200 bg-white px-5 py-3 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 dark:border-dark-700 dark:bg-dark-800 dark:text-gray-300 dark:hover:border-primary-500 dark:hover:text-primary-400"
            >
              Categories
            </button>

            <button
              type="button"
              onClick={openAddPanel}
              className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-primary-600/20 transition hover:bg-primary-700 active:scale-[0.99]"
            >
              + Add Product
            </button>
          </div>
        </div>

        {fetchError && (
          <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
            {fetchError}
          </div>
        )}

        {/* Stats */}
        <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <StatCard label="Active Products" value={stats.total} icon="⚙️" tone="primary" />
          <StatCard label="Low Stock" value={stats.lowStock} icon="⚠️" tone={stats.lowStock > 0 ? 'yellow' : 'default'} />
          <StatCard label="Out of Stock" value={stats.outOfStock} icon="🚫" tone={stats.outOfStock > 0 ? 'red' : 'default'} />
          <StatCard label="Inactive" value={stats.inactive} icon="🗄️" />
          <StatCard label="Inventory Value" value={formatPeso(stats.totalValue, 0)} icon="💰" tone="accent" />
        </div>

        {/* Filters */}
        <div className="mb-6 rounded-3xl border border-gray-200 bg-white p-4 shadow-sm dark:border-dark-700 dark:bg-dark-800">
          <div className="mb-4 flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => {
              const active = categoryFilter === category;

              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => setCategoryFilter(category)}
                  className={`rounded-full px-4 py-2 text-xs font-black capitalize transition ${
                    active
                      ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/20'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900 dark:bg-dark-900 dark:text-gray-400 dark:hover:bg-dark-700 dark:hover:text-white'
                  }`}
                >
                  {category === 'all' ? 'All Categories' : category}
                </button>
              );
            })}
          </div>

          <div className="grid gap-3 lg:grid-cols-[1fr_auto_auto_auto]">
            <input
              type="text"
              placeholder="Search product, category, or compatible model..."
              value={search}
              onChange={(event) => setSearch(sanitizeBasicText(event.target.value, 80))}
              className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-primary-500 focus:bg-white focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white dark:placeholder:text-gray-500"
            />

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
            >
              {STATUS_FILTERS.map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label}
                </option>
              ))}
            </select>

            <select
              value={stockFilter}
              onChange={(event) => setStockFilter(event.target.value)}
              className="rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
            >
              {STOCK_FILTERS.map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value)}
              className="rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
            >
              <option value="name">Sort: Name</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="stock_asc">Stock: Low to High</option>
              <option value="stock_desc">Stock: High to Low</option>
            </select>
          </div>
        </div>

        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-gray-500 dark:text-gray-400">
              Showing {filteredParts.length === 0 ? 0 : startIndex + 1}–{Math.min(endIndex, filteredParts.length)} of {filteredParts.length} filtered products
            </p>
            <p className="mt-1 text-xs font-semibold text-gray-400 dark:text-gray-500">
              Total records: {parts.length}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
              Per page
              <select
                value={pageSize}
                onChange={(event) => setPageSize(Number(event.target.value))}
                className="rounded-2xl border border-gray-200 bg-white px-3 py-2 text-sm font-black text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-800 dark:text-white"
              >
                {PAGE_SIZE_OPTIONS.map((size) => (
                  <option key={size} value={size}>
                    {size}
                  </option>
                ))}
              </select>
            </label>

            {(search || categoryFilter !== 'all' || stockFilter !== 'all' || statusFilter !== 'active' || sortBy !== 'name') && (
              <button
                type="button"
                onClick={clearFilters}
                className="text-sm font-black text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>

        {/* Parts grid */}
        {loading ? (
          <PartSkeleton />
        ) : filteredParts.length === 0 ? (
          <div className="rounded-3xl border border-gray-200 bg-white p-16 text-center shadow-sm dark:border-dark-700 dark:bg-dark-800">
            <div className="mx-auto mb-5 grid h-20 w-20 place-items-center rounded-3xl bg-primary-50 text-4xl ring-1 ring-primary-100 dark:bg-primary-500/10 dark:ring-primary-500/20">
              🔍
            </div>
            <h2 className="mb-2 text-xl font-black text-gray-950 dark:text-white">
              No products found
            </h2>
            <p className="mx-auto mb-6 max-w-md text-sm leading-6 text-gray-600 dark:text-gray-400">
              {parts.length === 0
                ? 'No products in inventory yet.'
                : 'No products match your current filters.'}
            </p>
            {parts.length === 0 ? (
              <button
                type="button"
                onClick={openAddPanel}
                className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-primary-600/20 transition hover:bg-primary-700"
              >
                Add your first product →
              </button>
            ) : (
              <button
                type="button"
                onClick={clearFilters}
                className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-primary-600/20 transition hover:bg-primary-700"
              >
                Clear filters
              </button>
            )}
          </div>
        ) : (
          <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {paginatedParts.map((part) => {
              const stockState = getStockState(part);
              const inactive = part.is_active === false;
              const stock = Number(part.stock_quantity) || 0;
              const threshold = Number(part.reorder_threshold ?? 5);
              const stockPct =
                threshold > 0
                  ? Math.min(100, (stock / (threshold * 3)) * 100)
                  : stock > 0
                  ? 100
                  : 0;

              return (
                <article
                  key={part.id}
                  className={`rounded-3xl border border-gray-200 bg-white p-5 shadow-sm transition hover:border-primary-100 dark:border-dark-700 dark:bg-dark-800 dark:hover:border-primary-500/30 ${
                    inactive ? 'opacity-60' : ''
                  }`}
                >
                  <div className="mb-4 flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-2xl bg-gray-50 ring-1 ring-gray-100 dark:bg-dark-900 dark:ring-dark-700">
                        {part.image_url ? (
                          <img
                            src={part.image_url}
                            alt={part.name}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="grid h-full w-full place-items-center text-2xl text-gray-400">
                            ⚙️
                          </div>
                        )}
                      </div>

                      <div className="min-w-0">
                        <p className="truncate text-sm font-black text-gray-950 dark:text-white" title={part.name}>
                          {part.name}
                        </p>
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                          {part.category || 'Uncategorized'}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-shrink-0 flex-col items-end gap-2">
                      {inactive && (
                        <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-black text-gray-500 ring-1 ring-gray-200 dark:bg-gray-500/10 dark:text-gray-300 dark:ring-gray-500/25">
                          Inactive
                        </span>
                      )}
                      <StockBadge state={stockState} />

                      <span
                        className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${
                          part.is_previewable === false
                            ? 'bg-gray-100 text-gray-500 ring-gray-200 dark:bg-gray-500/10 dark:text-gray-300 dark:ring-gray-500/25'
                            : 'bg-primary-50 text-primary-700 ring-primary-100 dark:bg-primary-500/10 dark:text-primary-300 dark:ring-primary-500/25'
                        }`}
                        title={
                          part.is_previewable === false
                            ? 'This product is for shop/inventory only and will not appear in AI Preview'
                            : 'This product can appear in AI Preview'
                        }
                      >
                        {part.is_previewable === false ? 'Shop Only' : 'Previewable'}
                      </span>

                      {part.is_previewable !== false && (
                        <span
                          className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${
                            part.ai_reference_url
                              ? 'bg-primary-50 text-primary-700 ring-primary-100 dark:bg-primary-500/10 dark:text-primary-300 dark:ring-primary-500/25'
                              : 'bg-gray-100 text-gray-500 ring-gray-200 dark:bg-gray-500/10 dark:text-gray-300 dark:ring-gray-500/25'
                          }`}
                          title={
                            part.ai_reference_url
                              ? 'Has clean AI reference image'
                              : 'No AI reference photo yet'
                          }
                        >
                          {part.ai_reference_url ? 'AI Ready' : 'No AI Ref'}
                        </span>
                      )}
                    </div>
                  </div>

                  {part.compatible_models?.length > 0 && (
                    <div className="mb-4 flex flex-wrap gap-1.5">
                      {part.compatible_models.slice(0, 3).map((model, index) => (
                        <span
                          key={`${model}-${index}`}
                          className="rounded-full bg-primary-50 px-2.5 py-1 text-xs font-bold text-primary-700 ring-1 ring-primary-100 dark:bg-primary-500/10 dark:text-primary-400 dark:ring-primary-500/20"
                        >
                          {model}
                        </span>
                      ))}
                      {part.compatible_models.length > 3 && (
                        <span className="self-center text-xs font-semibold text-gray-500 dark:text-gray-400">
                          +{part.compatible_models.length - 3} more
                        </span>
                      )}
                    </div>
                  )}

                  <div className="mb-4 grid grid-cols-2 gap-3">
                    <div className="rounded-2xl bg-gray-50 p-4 ring-1 ring-gray-100 dark:bg-dark-900/70 dark:ring-dark-700">
                      <p className="text-[11px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        Price
                      </p>
                      <p className="mt-1 text-sm font-black text-accent-600 dark:text-accent-400">
                        {formatPeso(part.price)}
                      </p>
                    </div>

                    <div className="rounded-2xl bg-gray-50 p-4 ring-1 ring-gray-100 dark:bg-dark-900/70 dark:ring-dark-700">
                      <p className="text-[11px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        Reorder At
                      </p>
                      <p className="mt-1 text-sm font-black text-gray-950 dark:text-white">
                        {threshold}
                      </p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="mb-2 flex items-center justify-between gap-3">
                      <p className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        Stock Quantity
                      </p>
                      <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
                        {stock} on hand
                      </p>
                    </div>

                    <div className="mb-3 h-2 overflow-hidden rounded-full bg-gray-200 dark:bg-dark-700">
                      <div
                        className={`h-full rounded-full transition-all ${STOCK_BAR[stockState]}`}
                        style={{ width: `${stockPct}%` }}
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => adjustStock(part, -1)}
                        disabled={stock <= 0 || updatingStockId === part.id}
                        className="grid h-10 w-10 place-items-center rounded-2xl border border-gray-200 bg-gray-50 text-lg font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:bg-dark-900 dark:text-gray-300 dark:hover:border-primary-500 dark:hover:text-primary-400"
                      >
                        −
                      </button>

                      <input
                        type="text"
                        inputMode="numeric"
                        value={stockEdits[part.id] ?? stock}
                        onChange={(event) =>
                          setStockEdits((previous) => ({
                            ...previous,
                            [part.id]: sanitizeIntegerInput(event.target.value, 6),
                          }))
                        }
                        onBlur={() => commitStockInput(part)}
                        onKeyDown={(event) => {
                          if (event.key === 'Enter') event.currentTarget.blur();
                        }}
                        disabled={updatingStockId === part.id}
                        className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-center text-sm font-black text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 disabled:opacity-50 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
                      />

                      <button
                        type="button"
                        onClick={() => adjustStock(part, 1)}
                        disabled={updatingStockId === part.id}
                        className="grid h-10 w-10 place-items-center rounded-2xl border border-gray-200 bg-gray-50 text-lg font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:bg-dark-900 dark:text-gray-300 dark:hover:border-primary-500 dark:hover:text-primary-400"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 border-t border-gray-100 pt-4 dark:border-dark-700">
                    <button
                      type="button"
                      onClick={() => openEditPanel(part)}
                      className="rounded-2xl bg-primary-50 px-4 py-2 text-xs font-black text-primary-700 ring-1 ring-primary-100 transition hover:bg-primary-100 dark:bg-primary-500/10 dark:text-primary-400 dark:ring-primary-500/25 dark:hover:bg-primary-500/20"
                    >
                      ✎ Edit
                    </button>

                    {inactive ? (
                      <button
                        type="button"
                        onClick={async () => {
                          const confirmed = await confirmAction(`Reactivate "${part.name}"?`);
                          if (confirmed) setPartActive(part, true);
                        }}
                        disabled={togglingId === part.id}
                        className="rounded-2xl bg-green-50 px-4 py-2 text-xs font-black text-green-700 ring-1 ring-green-200 transition hover:bg-green-100 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-green-500/10 dark:text-green-300 dark:ring-green-500/25 dark:hover:bg-green-500/20"
                      >
                        {togglingId === part.id ? 'Reactivating...' : '↺ Reactivate'}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={async () => {
                          const confirmed = await confirmAction({
                            title: 'Deactivate Product?',
                            message: `“${part.name}” will be hidden from customers but kept in your records. You can reactivate it at any time.`,
                            confirmLabel: 'Deactivate',
                            cancelLabel: 'Cancel',
                            tone: 'danger',
                          });

                          if (confirmed) {
                            await setPartActive(part, false);
                          }
                        }}
                        disabled={togglingId === part.id}
                        className="rounded-2xl bg-red-50 px-4 py-2 text-xs font-black text-red-700 ring-1 ring-red-200 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25 dark:hover:bg-red-500/20"
                      >
                        {togglingId === part.id ? 'Deactivating...' : '🚫 Deactivate'}
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>

          <div className="mt-6 flex flex-col gap-3 rounded-3xl border border-gray-200 bg-white p-4 shadow-sm dark:border-dark-700 dark:bg-dark-800 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-bold text-gray-500 dark:text-gray-400">
              Page {safeCurrentPage} of {totalPages}
            </p>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setCurrentPage(1)}
                disabled={safeCurrentPage <= 1}
                className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:text-gray-300"
              >
                First
              </button>

              <button
                type="button"
                onClick={() => setCurrentPage((page) => Math.max(page - 1, 1))}
                disabled={safeCurrentPage <= 1}
                className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:text-gray-300"
              >
                Prev
              </button>

              <span className="rounded-2xl bg-gray-100 px-4 py-2 text-sm font-black text-gray-700 dark:bg-dark-900 dark:text-gray-300">
                {safeCurrentPage} / {totalPages}
              </span>

              <button
                type="button"
                onClick={() => setCurrentPage((page) => Math.min(page + 1, totalPages))}
                disabled={safeCurrentPage >= totalPages}
                className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:text-gray-300"
              >
                Next
              </button>

              <button
                type="button"
                onClick={() => setCurrentPage(totalPages)}
                disabled={safeCurrentPage >= totalPages}
                className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 disabled:cursor-not-allowed disabled:opacity-40 dark:border-dark-700 dark:text-gray-300"
              >
                Last
              </button>
            </div>
          </div>
          </>
        )}
      </div>

      {/* Error Popup */}
      {errorPopup && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center bg-black/60 px-4">
          <div className="w-full max-w-md rounded-3xl border border-red-200 bg-white p-6 shadow-2xl dark:border-red-500/30 dark:bg-dark-800">
            <div className="mb-4 flex items-start gap-3">
              <div className="grid h-11 w-11 flex-shrink-0 place-items-center rounded-2xl bg-red-50 text-2xl ring-1 ring-red-100 dark:bg-red-500/10 dark:ring-red-500/25">
                ⚠️
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-lg font-black text-gray-950 dark:text-white">
                  Action Failed
                </p>
                <p className="mt-2 whitespace-pre-wrap text-sm font-semibold leading-6 text-red-700 dark:text-red-300">
                  {errorPopup}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={clearErrorPopup}
              className="w-full rounded-2xl bg-red-600 px-4 py-3 text-sm font-black text-white shadow-lg shadow-red-600/20 transition hover:bg-red-700"
            >
              Okay
            </button>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-[130] max-w-xs rounded-3xl border border-primary-100 bg-white px-5 py-4 text-sm font-black text-gray-950 shadow-2xl dark:border-primary-500/25 dark:bg-dark-800 dark:text-white">
          {toast}
        </div>
      )}

      {/* Manage Categories */}
      {catPanelOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm sm:p-6"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget && !catSaving) {
              setCatPanelOpen(false);
            }
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="manage-categories-title"
            className="relative flex max-h-[90vh] w-full max-w-xl flex-col overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-2xl dark:border-dark-700 dark:bg-dark-800"
          >
            <div className="flex items-center justify-between border-b border-gray-200 bg-white px-6 py-4 dark:border-dark-700 dark:bg-dark-800">
              <div>
                <h2
                  id="manage-categories-title"
                  className="text-lg font-black text-gray-950 dark:text-white"
                >
                  Manage Categories
                </h2>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Set which categories are Previewable or Shop Only.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setCatPanelOpen(false)}
                className="grid h-10 w-10 place-items-center rounded-2xl text-xl text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-dark-700 dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="min-h-0 flex-1 space-y-6 overflow-y-auto p-6">
              <div>
                <p className="mb-2 text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                  Add Category
                </p>

                <div className="space-y-3 rounded-3xl border border-gray-200 bg-gray-50 p-4 dark:border-dark-700 dark:bg-dark-900/70">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(event) => setNewCatName(sanitizeCategory(event.target.value))}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter') addCustomCategory();
                    }}
                    placeholder="e.g. Exhaust, Oil, Mags, Seat"
                    className="w-full rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-800 dark:text-white"
                  />

                  <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-gray-200 bg-white p-3 dark:border-dark-700 dark:bg-dark-800">
                    <input
                      type="checkbox"
                      checked={newCatPreviewable}
                      onChange={(event) => setNewCatPreviewable(event.target.checked)}
                      className="mt-1 h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span>
                      <span className="block text-sm font-black text-gray-900 dark:text-white">
                        Available for AI Preview
                      </span>
                      <span className="mt-1 block text-xs font-semibold leading-5 text-gray-500 dark:text-gray-400">
                        Enable this only for visible motorcycle parts like mags, exhaust, seat, lights, or body panels.
                      </span>
                    </span>
                  </label>

                  <button
                    type="button"
                    onClick={addCustomCategory}
                    disabled={!newCatName.trim() || catSaving}
                    className="w-full rounded-2xl bg-primary-600 px-5 py-3 text-sm font-black text-white transition hover:bg-primary-700 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {catSaving ? 'Saving...' : 'Add Category'}
                  </button>
                </div>
              </div>

              <div>
                <p className="mb-3 text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                  Product Categories ({allCategories.length})
                </p>

                {allCategories.length === 0 ? (
                  <div className="rounded-3xl border border-dashed border-gray-300 bg-gray-50 p-8 text-center dark:border-dark-700 dark:bg-dark-900/60">
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400">
                      No categories yet. Add one above.
                    </p>
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {allCategories.map((category) => {
                      const partCount = parts.filter((part) => part.category === category).length;
                      const isRenaming = renamingCat?.old === category;
                      const categoryRecord = getCategoryRecord(category, categoryRecords);
                      const isPreviewable = categoryRecord?.is_previewable === true;

                      return (
                        <li
                          key={category}
                          className="rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3 dark:border-dark-700 dark:bg-dark-900/70"
                        >
                          {isRenaming ? (
                            <div className="flex items-center gap-2">
                              <input
                                autoFocus
                                type="text"
                                value={renamingCat.value}
                                onChange={(event) =>
                                  setRenamingCat({
                                    ...renamingCat,
                                    value: sanitizeCategory(event.target.value),
                                  })
                                }
                                onKeyDown={(event) => {
                                  if (event.key === 'Enter') renameCategory(category, renamingCat.value);
                                  if (event.key === 'Escape') setRenamingCat(null);
                                }}
                                className="flex-1 rounded-xl border border-primary-500 bg-white px-3 py-2 text-sm font-semibold text-gray-900 outline-none dark:bg-dark-800 dark:text-white"
                              />

                              <button
                                type="button"
                                onClick={() => renameCategory(category, renamingCat.value)}
                                disabled={catSaving}
                                className="rounded-xl bg-primary-600 px-3 py-2 text-xs font-black text-white transition hover:bg-primary-700 disabled:opacity-50"
                              >
                                {catSaving ? '…' : 'Save'}
                              </button>

                              <button
                                type="button"
                                onClick={() => setRenamingCat(null)}
                                className="rounded-xl px-2 py-2 text-xs font-black text-gray-500 transition hover:text-gray-900 dark:hover:text-white"
                              >
                                ✕
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-3">
                              <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0">
                                  <p className="truncate text-sm font-black capitalize text-gray-950 dark:text-white">
                                    {category}
                                  </p>
                                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                                    {partCount} {partCount === 1 ? 'product' : 'products'} · {isPreviewable ? 'Previewable' : 'Shop Only'}
                                  </p>
                                </div>

                                <span
                                  className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${
                                    isPreviewable
                                      ? 'bg-primary-50 text-primary-700 ring-primary-100 dark:bg-primary-500/10 dark:text-primary-300 dark:ring-primary-500/25'
                                      : 'bg-gray-100 text-gray-500 ring-gray-200 dark:bg-gray-500/10 dark:text-gray-300 dark:ring-gray-500/25'
                                  }`}
                                >
                                  {isPreviewable ? 'Previewable' : 'Shop Only'}
                                </span>
                              </div>

                              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl bg-white px-3 py-2 dark:bg-dark-800">
                                <span className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                                  AI Preview
                                </span>
                                <input
                                  type="checkbox"
                                  checked={isPreviewable}
                                  onChange={(event) =>
                                    toggleCategoryPreviewable(category, event.target.checked)
                                  }
                                  disabled={catSaving || !categoryRecord?.id}
                                  className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 disabled:opacity-40"
                                />
                              </label>

                              <div className="flex gap-1">
                                <button
                                  type="button"
                                  onClick={() => setRenamingCat({ old: category, value: category })}
                                  className="rounded-xl bg-primary-50 px-3 py-2 text-xs font-black text-primary-700 transition hover:bg-primary-100 dark:bg-primary-500/10 dark:text-primary-400 dark:hover:bg-primary-500/20"
                                  title="Rename"
                                >
                                  ✎ Rename
                                </button>

                                <button
                                  type="button"
                                  onClick={() => deleteCategory(category)}
                                  disabled={catSaving}
                                  className="rounded-xl bg-red-50 px-3 py-2 text-xs font-black text-red-700 transition hover:bg-red-100 disabled:opacity-50 dark:bg-red-500/10 dark:text-red-300 dark:hover:bg-red-500/20"
                                  title="Delete"
                                >
                                  🗑 Remove
                                </button>
                              </div>
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Add/Edit Product */}
      {panelOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm sm:p-6"
          role="presentation"
          onMouseDown={(event) => {
            if (
              event.target === event.currentTarget &&
              !saving &&
              !uploadingImage &&
              !uploadingAiReference
            ) {
              closePanel();
            }
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="product-modal-title"
            className="relative flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-2xl dark:border-dark-700 dark:bg-dark-800"
          >
            <header className="flex items-start justify-between gap-4 border-b border-gray-200 bg-white px-6 py-5 dark:border-dark-700 dark:bg-dark-800 sm:px-8">
              <div className="min-w-0">
                <p className="text-xs font-black uppercase tracking-[0.18em] text-primary-600 dark:text-primary-400">
                  Product Management
                </p>
                <h2
                  id="product-modal-title"
                  className="mt-1 text-xl font-black text-gray-950 dark:text-white sm:text-2xl"
                >
                  {editingId ? 'Edit Product' : 'Add New Product'}
                </h2>
                <p className="mt-1 text-sm leading-6 text-gray-500 dark:text-gray-400">
                  {editingId
                    ? 'Update product details, inventory, compatibility, and AI preview information.'
                    : 'Create a product and configure its inventory, compatible motorcycles, and preview settings.'}
                </p>
              </div>

              <button
                type="button"
                onClick={closePanel}
                disabled={saving || uploadingImage || uploadingAiReference}
                aria-label="Close product modal"
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-gray-200 text-lg font-black text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 disabled:cursor-not-allowed disabled:opacity-50 dark:border-dark-600 dark:hover:bg-dark-700 dark:hover:text-white"
              >
                ✕
              </button>
            </header>

            <form
              onSubmit={handleSubmit}
              className="min-h-0 flex-1 space-y-5 overflow-y-auto px-6 py-6 sm:px-8"
            >
              {formError && (
                <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
                  {formError}
                </div>
              )}

              <div>
                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                  Category First *
                </label>

                {allCategories.length > 0 && !showCategoryInput ? (
                  <select
                    name="category"
                    value={allCategories.includes(form.category) ? form.category : ''}
                    onChange={handleCategorySelect}
                    className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
                  >
                    <option value="">— Select a category first —</option>
                    {allCategories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                    <option value="__other__">Other (type new)…</option>
                  </select>
                ) : (
                  <div className="flex gap-2">
                    <input
                      name="category"
                      value={form.category}
                      onChange={handleCategoryInputChange}
                      placeholder="e.g. Exhaust, Mags, Seat, Oil"
                      autoFocus={showCategoryInput}
                      className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-primary-500 focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
                    />

                    {allCategories.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowCategoryInput(false)}
                        className="rounded-2xl border border-gray-200 px-4 py-3 text-sm font-black text-gray-700 transition hover:border-primary-400 hover:text-primary-700 dark:border-dark-700 dark:text-gray-300"
                      >
                        List
                      </button>
                    )}
                  </div>
                )}

                <div className="mt-3 rounded-2xl border border-gray-200 bg-gray-50 p-4 dark:border-dark-700 dark:bg-dark-900">
                  <p className="text-sm font-black text-gray-900 dark:text-white">
                    AI Preview Status: {categoryPreviewInfo.label}
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-5 text-gray-500 dark:text-gray-400">
                    {categoryPreviewInfo.helper}
                  </p>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                  Product Image
                </label>

                <div className="flex items-center gap-3">
                  <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-2xl bg-gray-50 ring-1 ring-gray-100 dark:bg-dark-900 dark:ring-dark-700">
                    {form.image_url ? (
                      <img
                        src={form.image_url}
                        alt=""
                        className="h-full w-full object-cover"
                        onError={(event) => {
                          event.currentTarget.style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center text-2xl text-gray-400">
                        ⚙️
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <label
                      className={`mb-2 inline-flex items-center justify-center rounded-2xl px-4 py-3 text-sm font-black text-white shadow-lg transition ${
                        hasSelectedCategory
                          ? 'cursor-pointer bg-primary-600 shadow-primary-600/20 hover:bg-primary-700'
                          : 'cursor-not-allowed bg-gray-400 shadow-none'
                      }`}
                    >
                      {!hasSelectedCategory
                        ? 'Select Category First'
                        : uploadingImage
                        ? 'Uploading...'
                        : 'Upload Product Image'}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleProductImageUpload}
                        disabled={!hasSelectedCategory || uploadingImage || saving}
                        className="hidden"
                      />
                    </label>
                    <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                      Select the category first so the system can decide if this product is Previewable or Shop Only.
                    </p>
                  </div>
                </div>
              </div>

              {categoryPreviewInfo.isPreviewable && (
                <>
                  <div>
                    <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                      AI Reference Image
                    </label>

                    <div className="flex items-center gap-3">
                      <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-2xl bg-gray-50 ring-1 ring-gray-100 dark:bg-dark-900 dark:ring-dark-700">
                        {form.ai_reference_url ? (
                          <img
                            src={form.ai_reference_url}
                            alt=""
                            className="h-full w-full object-cover"
                            onError={(event) => {
                              event.currentTarget.style.display = 'none';
                            }}
                          />
                        ) : (
                          <div className="grid h-full w-full place-items-center text-xs font-black text-gray-400">
                            AI Ref
                          </div>
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <label className="mb-2 inline-flex cursor-pointer items-center justify-center rounded-2xl bg-accent-500 px-4 py-3 text-sm font-black text-white shadow-lg shadow-accent-500/20 transition hover:bg-accent-600">
                          {uploadingAiReference ? 'Uploading...' : 'Upload AI Reference'}
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleAiReferenceUpload}
                            disabled={uploadingAiReference || saving}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>

                    <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                      Upload one clean cropped photo of the exact product only.
                    </p>
                  </div>

                  <TextInput
                    label="AI Prompt Description"
                    name="prompt_description"
                    value={form.prompt_description}
                    onChange={handleChange}
                    placeholder="e.g. gold Enkei 3-spoke mags with glossy metallic alloy finish"
                    helper="Describe the exact shape, material, color, and finish. This helps the AI replace the real product instead of only recoloring it."
                  />

                  <div>
                    <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                      Install Area
                    </label>

                    <select
                      name="install_area"
                      value={
                        INSTALL_AREA_OPTIONS.includes(form.install_area)
                          ? form.install_area
                          : ''
                      }
                      onChange={(event) =>
                        setForm((current) => ({
                          ...current,
                          install_area: event.target.value,
                        }))
                      }
                      className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:bg-white focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
                    >
                      <option value="">— Select install area —</option>
                      {INSTALL_AREA_OPTIONS.map((area) => (
                        <option key={area} value={area}>
                          {area}
                        </option>
                      ))}
                    </select>

                    <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                      Choose a predefined install area so AI Preview uses consistent placement instructions.
                    </p>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-3">
                    <TextInput
                      label="Color"
                      name="color"
                      value={form.color}
                      onChange={handleChange}
                      placeholder="Gold"
                    />

                    <TextInput
                      label="Finish"
                      name="finish"
                      value={form.finish}
                      onChange={handleChange}
                      placeholder="Gloss metallic"
                    />

                    <TextInput
                      label="Material"
                      name="material"
                      value={form.material}
                      onChange={handleChange}
                      placeholder="Alloy"
                    />
                  </div>
                </>
              )}

              <TextInput
                label="Product Name *"
                name="name"
                value={form.name}
                onChange={handleChange}
                required
                maxLength={100}
                placeholder="e.g. Brake Pad Set"
                helper="Allowed: letters, numbers, spaces, ñ, and basic symbols only."
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <TextInput
                  label="Price *"
                  name="price"
                  type="text"
                  inputMode="decimal"
                  value={form.price}
                  onChange={handleChange}
                  required
                  placeholder="0.00"
                />

                <TextInput
                  label="Stock Quantity *"
                  name="stock_quantity"
                  type="text"
                  inputMode="numeric"
                  value={form.stock_quantity}
                  onChange={handleChange}
                  required
                  placeholder="0"
                />
              </div>

              <TextInput
                label="Reorder Threshold"
                name="reorder_threshold"
                type="text"
                inputMode="numeric"
                value={form.reorder_threshold}
                onChange={handleChange}
                helper="Products at or below this quantity are flagged as low stock. Numbers only."
              />

              <div>
                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                  Compatible Models
                </label>

                <select
                  value=""
                  onChange={(event) => {
                    if (!event.target.value) return;
                    toggleCompatibleModel(event.target.value);
                  }}
                  className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm font-semibold text-gray-900 outline-none transition focus:border-primary-500 focus:bg-white focus:ring-4 focus:ring-primary-500/10 dark:border-dark-700 dark:bg-dark-900 dark:text-white"
                >
                  <option value="">
                    {motorcycleModels.length > 0
                      ? '— Select compatible motorcycle model —'
                      : 'No motorcycle models found'}
                  </option>
                  {motorcycleModels.map((model) => {
                    const selected = selectedCompatibleModels.some(
                      (item) => item.toLowerCase() === model.label.toLowerCase()
                    );

                    return (
                      <option key={model.id || model.label} value={model.label}>
                        {selected ? '✓ ' : ''}{model.label}
                      </option>
                    );
                  })}
                </select>

                <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                  Choose from predefined motorcycle models. Click a selected model below to remove it.
                </p>

                {selectedCompatibleModels.length > 0 ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {selectedCompatibleModels.map((model) => (
                      <button
                        key={model}
                        type="button"
                        onClick={() => toggleCompatibleModel(model)}
                        className="rounded-full bg-primary-100 px-3 py-1.5 text-xs font-black text-primary-700 ring-1 ring-primary-200 transition hover:bg-primary-200 dark:bg-primary-500/10 dark:text-primary-300 dark:ring-primary-500/25"
                      >
                        {model} ✕
                      </button>
                    ))}

                    <button
                      type="button"
                      onClick={clearCompatibleModels}
                      className="rounded-full bg-red-50 px-3 py-1.5 text-xs font-black text-red-700 ring-1 ring-red-200 transition hover:bg-red-100 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25"
                    >
                      Clear all
                    </button>
                  </div>
                ) : (
                  <div className="mt-3 rounded-2xl border border-dashed border-gray-300 bg-gray-50 p-4 text-center text-xs font-semibold text-gray-500 dark:border-dark-700 dark:bg-dark-900/70 dark:text-gray-400">
                    No compatible model selected yet.
                  </div>
                )}
              </div>

              <footer className="sticky -bottom-6 -mx-6 mt-6 flex flex-col-reverse gap-3 border-t border-gray-200 bg-white px-6 py-5 dark:border-dark-700 dark:bg-dark-800 sm:-mx-8 sm:flex-row sm:justify-end sm:px-8">
                <button
                  type="button"
                  onClick={closePanel}
                  disabled={saving || uploadingImage || uploadingAiReference}
                  className="rounded-2xl border border-gray-200 bg-white px-6 py-3 text-sm font-black text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50 dark:border-dark-600 dark:bg-dark-800 dark:text-gray-200 dark:hover:bg-dark-700"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={saving || uploadingImage || uploadingAiReference}
                  className="rounded-2xl bg-primary-600 px-7 py-3 text-sm font-black text-white shadow-lg shadow-primary-600/20 transition hover:bg-primary-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {saving
                    ? 'Saving...'
                    : editingId
                    ? 'Save Changes'
                    : '+ Add Product'}
                </button>
              </footer>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}